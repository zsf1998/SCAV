time ./test.sh

